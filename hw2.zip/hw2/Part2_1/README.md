Part 2 Digital Visualization
Create a digital visualization for the same small dataset from A1 and provide rigorous rationale for your design choices. 
In theory, you should be in a position to explain how every pixel contributes to your visualization. 
You are free to use any graphical tool you are comfortable with, including Tableau, Adobe Illustrator, PowerPoint, Autodesk Sketchbook, Microsoft Excel, Paint. You could also create a chart from scratch using a visualization package of your choice. 